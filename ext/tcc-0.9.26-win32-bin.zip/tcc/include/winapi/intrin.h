/**
 * This file has no copyright assigned and is placed in the Public Domain.
 * This file is part of the w64 mingw-runtime package.
 * No warranty is given; refer to the file DISCLAIMER within this package.
 */
#ifndef __INTRIN_H_
#define __INTRIN_H_

//!__TINYC__: intrinsic stuff removed

#endif /* end __INTRIN_H_ */
